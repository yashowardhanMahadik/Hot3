package com.hotl4.BadHotel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BadHotelApplicationTests {

	@Test
	void contextLoads() {
	}

}
