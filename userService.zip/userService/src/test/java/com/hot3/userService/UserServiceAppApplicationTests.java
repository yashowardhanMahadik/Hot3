package com.hot3.userService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserServiceAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
